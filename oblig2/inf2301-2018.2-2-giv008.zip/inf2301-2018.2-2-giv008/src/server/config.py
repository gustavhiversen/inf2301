HOST = "localhost"
PORT = 8080
