Part A:
	To test the implementation type in the terminal "python3 server.py"
	To test GET write in your browser localhost:8080, localhost:8080/testpage.html, localhost:8080/test.txt
	To test the POST open localhost:8080 and type inside of the text to post block

Part B:
	To test the implementation type in the terminal "python3 server.py"
	To test GET use a restclient and request GET to /message
	To test POST use a restclient and request POST to /message with for example {"data": "text"} as input, data is the key
	To test PUT use a restclient and request PUT to /message with for example {"data": "text", "id" : 5} as input, data and id is the keys
	To test DELETE use a restclient and request DELETE to /message with for example {"id": 5} as input.
