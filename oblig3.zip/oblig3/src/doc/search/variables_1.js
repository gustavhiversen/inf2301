var searchData=
[
  ['callback',['callback',['../structtick__timer.html#a35b805ac38456f519a16f61a263fcb5d',1,'tick_timer']]],
  ['corrupt_5fprob',['corrupt_prob',['../structnetwork__layer.html#a84bb40a501a66babb22a58e275659484',1,'network_layer']]],
  ['ctx',['ctx',['../structtick__timer.html#a1f6d09b30c54854dfca659b7463ac207',1,'tick_timer']]]
];
