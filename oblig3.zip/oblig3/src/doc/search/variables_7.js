var searchData=
[
  ['remote_5fstack',['remote_stack',['../structnetwork__layer.html#a890c04237b695563304057f0de25dbf4',1,'network_layer']]]
];
