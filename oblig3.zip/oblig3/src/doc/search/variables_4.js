var searchData=
[
  ['loss_5fprob',['loss_prob',['../structnetwork__layer.html#a4cbdc73444316d7427107b856fb3cbab',1,'network_layer']]]
];
