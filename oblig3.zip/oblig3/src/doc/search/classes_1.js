var searchData=
[
  ['network_5flayer',['network_layer',['../structnetwork__layer.html',1,'']]]
];
