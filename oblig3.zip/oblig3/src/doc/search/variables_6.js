var searchData=
[
  ['osi_5fstack',['osi_stack',['../structapplication__layer.html#a40c5e74a7ccdb267e0c75eb5e0a97c79',1,'application_layer::osi_stack()'],['../structnetwork__layer.html#a40c5e74a7ccdb267e0c75eb5e0a97c79',1,'network_layer::osi_stack()'],['../structtransport__layer.html#a40c5e74a7ccdb267e0c75eb5e0a97c79',1,'transport_layer::osi_stack()']]]
];
