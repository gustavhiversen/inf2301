var searchData=
[
  ['max_5fapp_5fdata_5fsize',['MAX_APP_DATA_SIZE',['../application__layer__impl_8h.html#ac8dff2d9f978a88bd28d4665206fffe7',1,'application_layer_impl.h']]]
];
