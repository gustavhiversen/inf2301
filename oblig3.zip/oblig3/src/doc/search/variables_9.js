var searchData=
[
  ['target_5fticks',['target_ticks',['../structtick__timer.html#a1d444dd10a56a30120f5a50b8c0aad37',1,'tick_timer']]],
  ['tick_5fcount',['tick_count',['../structtick__timer.html#a9d93d8d29468a024d53a54e595e46846',1,'tick_timer']]],
  ['tp_5flayer',['tp_layer',['../structosi__stack.html#aeede1bf0a193eab7ca5cdac90176ceb1',1,'osi_stack']]],
  ['trace_5flevel',['TRACE_LEVEL',['../diagnostics_8h.html#a13f78488dacec43e34b68bf1423f1fc1',1,'program.c']]],
  ['transmit_5fcallback',['transmit_callback',['../structnetwork__layer.html#ac60b560fded9476f434535483b806e0b',1,'network_layer']]]
];
